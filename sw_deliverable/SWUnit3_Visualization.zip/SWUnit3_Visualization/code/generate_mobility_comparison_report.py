#!/usr/bin/env python3
"""
Waypoint vs. Gauss-Markov mobility comparison report (Phase 2 Item 1
deliverable: mobility_comparison_report.pdf / .md).

Scans Waypoint_outputs/{patrol,transport,work,gaussmarkov_baseline}/spd*/seed*/
run directories produced by run_waypoint_scenarios.py, aggregates switching
frequency, switching burstiness, RSSI-change abruptness, and service
interruption duration across seeds, and writes a Markdown report (plus a PDF
via weasyprint if available) that checks the results against the specific
claims in NS3_Simulation_Enhancement_Plan_EN.docx section 2.4 ("Expected
Effects"): RSSI variation should go from continuous/gradual to reproducing
abrupt-change zones, and switching events should go from dispersed to
concentrated near shadow zones.

Usage (from ns-3.45/):
    python3 examples/my-scenarios/generate_mobility_comparison_report.py
    python3 examples/my-scenarios/generate_mobility_comparison_report.py \\
        --root Waypoint_outputs --out Waypoint_outputs/mobility_comparison_report
"""
import argparse
import csv
import re
import statistics
import sys
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt

SCENARIOS = ["gaussmarkov_baseline", "patrol", "transport", "work"]
BASELINE_SPEED = 5.0  # matches the existing Gauss-Markov default speed; overridable via --baseline-speed

REPORT_AUTHOR = "Sheikh Sayed Bin Rahman"
REPORT_ID = "2025210714"
REPORT_LAB = "PIC Lab , KIT"


def read_switch_metrics(switch_csv, sim_time):
    if not switch_csv.exists():
        return None
    events = []
    with open(switch_csv) as f:
        for row in csv.DictReader(f):
            try:
                t = float(row["trigger_time_s"])
                interruption = float(row["service_interruption_ms"])
                status = row["status"]
            except (ValueError, KeyError):
                continue
            events.append((t, interruption, status))

    n_events = len(events)
    events_per_100s = n_events / (sim_time / 100.0) if sim_time > 0 else 0.0

    resolved = [e[1] for e in events if e[2] == "resolved"]
    mean_interruption = statistics.mean(resolved) if resolved else float("nan")
    p95_interruption = (
        sorted(resolved)[int(0.95 * (len(resolved) - 1))] if len(resolved) > 1 else
        (resolved[0] if resolved else float("nan"))
    )

    # Burstiness: bin trigger times into 10 windows across sim_time and take the
    # coefficient of variation of per-bin counts. Higher = more concentrated in
    # specific time windows (shadow zones); lower = more uniformly spread out.
    n_bins = 10
    bin_counts = [0] * n_bins
    for t, _, _ in events:
        idx = min(n_bins - 1, int((t / sim_time) * n_bins)) if sim_time > 0 else 0
        bin_counts[idx] += 1
    mean_count = statistics.mean(bin_counts)
    burstiness = (statistics.pstdev(bin_counts) / mean_count) if mean_count > 0 else 0.0

    return {
        "n_events": n_events,
        "events_per_100s": events_per_100s,
        "mean_interruption_ms": mean_interruption,
        "p95_interruption_ms": p95_interruption,
        "burstiness": burstiness,
    }


def read_rssi_abruptness(rssi_csv, resample_dt=1.0):
    """
    RSSI samples arrive far faster than once per second (every WiFi frame),
    so raw consecutive-row deltas are dominated by sub-second EWA noise and
    stay near zero regardless of real movement. Resample each STA's WiFi
    avg_rssi_dbm onto a fixed dt grid (hold-last-value) first, so deltas
    reflect actual second-to-second signal change, not oversampling.
    """
    if not rssi_csv.exists():
        return None
    per_sta = {}
    with open(rssi_csv) as f:
        for row in csv.DictReader(f):
            if row.get("rat") != "wifi":
                continue
            try:
                t = float(row["time_s"])
                sta = int(row["sta_index"])
                rssi = float(row["avg_rssi_dbm"])
            except (ValueError, KeyError):
                continue
            per_sta.setdefault(sta, []).append((t, rssi))

    deltas = []
    for sta, samples in per_sta.items():
        samples.sort(key=lambda r: r[0])
        if len(samples) < 2:
            continue
        max_t = samples[-1][0]
        grid = []
        i = 0
        n = len(samples)
        t = 0.0
        while t <= max_t + 1e-9:
            while i + 1 < n and samples[i + 1][0] <= t:
                i += 1
            grid.append(samples[i][1])
            t += resample_dt
        for r0, r1 in zip(grid, grid[1:]):
            deltas.append(abs(r1 - r0))

    if not deltas:
        return None
    deltas.sort()
    mean_delta = statistics.mean(deltas)
    p95_delta = deltas[int(0.95 * (len(deltas) - 1))]
    return {"mean_abs_rssi_delta": mean_delta, "p95_abs_rssi_delta": p95_delta}


def read_pdr(metrics_md):
    if not metrics_md.exists():
        return None
    text = metrics_md.read_text()
    m = re.search(r"Packet-weighted PDR \(%\):\s*\*\*([\d.]+)\*\*", text)
    return float(m.group(1)) if m else None


def collect_run(run_dir, sim_time):
    switch_metrics = read_switch_metrics(run_dir / "wifi-hybrid-switch_log.csv", sim_time)
    rssi_metrics = read_rssi_abruptness(run_dir / "wifi-hybrid-rssi_log.csv")
    pdr = read_pdr(run_dir / "wifi-hybrid-metrics_data.md")
    if switch_metrics is None or rssi_metrics is None:
        return None
    merged = {**switch_metrics, **rssi_metrics, "pdr": pdr}
    return merged


def aggregate(values):
    values = [v for v in values if v is not None and v == v]  # drop None/NaN
    if not values:
        return (float("nan"), float("nan"))
    if len(values) == 1:
        return (values[0], 0.0)
    return (statistics.mean(values), statistics.stdev(values))


def scan_scenario(root, scenario, sim_time):
    scenario_dir = root / scenario
    if not scenario_dir.exists():
        return {}
    by_speed = {}
    for speed_dir in sorted(scenario_dir.glob("spd*")):
        speed = speed_dir.name.replace("spd", "")
        runs = []
        for seed_dir in sorted(speed_dir.glob("seed*")):
            run = collect_run(seed_dir, sim_time)
            if run:
                runs.append(run)
        if runs:
            by_speed[speed] = runs
    return by_speed


def _wrap_chart_grids(html):
    """Wrap consecutive <p><img></p> blocks (already-converted HTML) in a
    chart-grid div so figures lay out side by side in the PDF, matching
    analysis_report_updated/md_to_pdf.py's approach."""
    pattern = re.compile(r"((?:<p>\s*<img[^>]+>\s*</p>\s*){2,})", re.MULTILINE)
    return pattern.sub(lambda m: f'<div class="chart-grid">{m.group(1)}</div>', html)


def fmt(mean, std, decimals=2):
    if mean != mean:
        return "n/a"
    return f"{mean:.{decimals}f} ± {std:.{decimals}f}"


def main():
    global BASELINE_SPEED

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", default="Waypoint_outputs")
    parser.add_argument("--sim-time", type=float, default=90.0)
    parser.add_argument("--out", default="Waypoint_outputs/mobility_comparison_report")
    parser.add_argument("--no-pdf", action="store_true")
    parser.add_argument("--baseline-speed", type=float, default=BASELINE_SPEED,
                         help="Speed (m/s) used for the head-to-head table (default 5.0)")
    args = parser.parse_args()

    BASELINE_SPEED = args.baseline_speed

    root = Path(args.root)
    data = {s: scan_scenario(root, s, args.sim_time) for s in SCENARIOS}

    if not any(data.values()):
        print(f"No run data found under {root}. Run run_waypoint_scenarios.py first.", file=sys.stderr)
        sys.exit(1)

    out_path = Path(args.out)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    assets_dir = out_path.parent / "report_assets"
    assets_dir.mkdir(exist_ok=True)

    # --- Head-to-head table at the baseline speed (5.0 m/s) ---
    headline_rows = []
    for scenario in SCENARIOS:
        runs = data[scenario].get(str(BASELINE_SPEED), [])
        if not runs:
            continue
        row = {"scenario": scenario, "n_runs": len(runs)}
        for key in ["events_per_100s", "burstiness", "mean_abs_rssi_delta",
                    "p95_abs_rssi_delta", "mean_interruption_ms", "pdr"]:
            mean, std = aggregate([r[key] for r in runs])
            row[key] = (mean, std)
        headline_rows.append(row)

    # --- Speed-sensitivity table (waypoint scenarios only) ---
    speed_rows = []
    for scenario in ["patrol", "transport", "work"]:
        for speed, runs in data[scenario].items():
            row = {"scenario": scenario, "speed": speed, "n_runs": len(runs)}
            for key in ["events_per_100s", "burstiness", "mean_abs_rssi_delta", "p95_abs_rssi_delta"]:
                mean, std = aggregate([r[key] for r in runs])
                row[key] = (mean, std)
            speed_rows.append(row)
    speed_rows.sort(key=lambda r: (r["scenario"], float(r["speed"])))

    # --- Charts ---
    def bar_chart(rows, key, title, ylabel, filename):
        labels = [r["scenario"] for r in rows]
        means = [r[key][0] for r in rows]
        stds = [r[key][1] for r in rows]
        fig, axis = plt.subplots(figsize=(6, 4))
        axis.bar(labels, means, yerr=stds, capsize=4, color="#2563eb")
        axis.set_title(title)
        axis.set_ylabel(ylabel)
        fig.tight_layout()
        fig.savefig(assets_dir / filename, dpi=140)
        plt.close(fig)

    if headline_rows:
        bar_chart(headline_rows, "events_per_100s",
                  f"Switching Frequency @ {BASELINE_SPEED} m/s", "events / 100s",
                  "chart_events_per_100s.png")
        bar_chart(headline_rows, "burstiness",
                  f"Switching Burstiness @ {BASELINE_SPEED} m/s",
                  "coefficient of variation (bin counts)", "chart_burstiness.png")
        bar_chart(headline_rows, "p95_abs_rssi_delta",
                  f"RSSI Change Abruptness (p95) @ {BASELINE_SPEED} m/s", "|Δ RSSI| dB (p95)",
                  "chart_rssi_abruptness.png")
        bar_chart(headline_rows, "mean_interruption_ms",
                  f"Mean Service Interruption @ {BASELINE_SPEED} m/s", "ms",
                  "chart_interruption.png")

    # --- Markdown report (style matches analysis_report_updated/hybrid_comparison_report.md) ---
    gm = next((r for r in headline_rows if r["scenario"] == "gaussmarkov_baseline"), None)
    wp_rows = [r for r in headline_rows if r["scenario"] != "gaussmarkov_baseline"]
    wp_burst_mean = wp_rssi_p95_mean = None
    burst_confirmed = rssi_confirmed = None
    if gm and wp_rows:
        wp_burst_mean = statistics.mean([r["burstiness"][0] for r in wp_rows if r["burstiness"][0] == r["burstiness"][0]])
        wp_rssi_p95_mean = statistics.mean([r["p95_abs_rssi_delta"][0] for r in wp_rows if r["p95_abs_rssi_delta"][0] == r["p95_abs_rssi_delta"][0]])
        burst_confirmed = wp_burst_mean > gm["burstiness"][0]
        rssi_confirmed = wp_rssi_p95_mean > gm["p95_abs_rssi_delta"][0]

    def scenario_run_count(scenario):
        return sum(len(v) for v in data[scenario].values())

    total_runs = sum(scenario_run_count(s) for s in SCENARIOS)

    seeds_found = sorted({
        seed_dir.name.replace("seed", "")
        for s in SCENARIOS
        for speed_dir in (root / s).glob("spd*")
        for seed_dir in speed_dir.glob("seed*")
    }, key=lambda v: int(v)) if any((root / s).exists() for s in SCENARIOS) else []

    lines = []
    lines.append("# Waypoint vs. Gauss-Markov Mobility Comparison: (Phase 2 Item 1)")
    lines.append("")
    lines.append(f"- Author : {REPORT_AUTHOR}")
    lines.append(f"- ID: {REPORT_ID}")
    lines.append(f"- Lab: {REPORT_LAB}")
    lines.append(f"- **Distinct scenario/speed configurations evaluated:** {total_runs}")
    lines.append("")

    lines.append("### Experimental design overview")
    lines.append("")
    lines.append("Each configuration corresponds to one simulation run comparing the new "
                 "Waypoint + dwell-time mobility model (patrol / transport / work robot "
                 "archetypes, now with real 3D height variation) against the existing "
                 "GaussMarkovMobilityModel baseline, evaluating whether structured robot "
                 "movement changes WiFi-cellular switching behavior versus a random walk.")
    lines.append("")
    lines.append("| Design element | Specification |")
    lines.append("| --- | --- |")
    lines.append(f"| Total configurations | {total_runs} simulation runs |")
    lines.append("| Scenarios | gaussmarkov_baseline, patrol, transport, work |")
    lines.append("| Speeds swept | 0.5, 2.0, 5.0 m/s (waypoint); "
                 f"{BASELINE_SPEED} m/s (baseline head-to-head) |")
    lines.append(f"| RNG seeds | {', '.join(seeds_found) if seeds_found else 'none found'} "
                 "(project convention reserves 6, 7, 8 for 3-repetition averages) |")
    lines.append(f"| Parameters held constant | STA count 5; simulation duration "
                 f"{args.sim_time:.0f}s; RSSI handover threshold −80 dBm |")
    lines.append("")

    # ---- Section 1: Head-to-head ----
    lines.append(f"## 1. Head-to-Head Comparison @ {BASELINE_SPEED} m/s")
    lines.append("")
    lines.append("This section presents the top-level switching and signal-quality indicators "
                 "for each mobility scenario at the shared baseline speed, before the "
                 "per-speed breakdown in Section 2.")
    lines.append("")
    lines.append("### Section Summary")
    lines.append("")
    if headline_rows:
        best_pdr = max(headline_rows, key=lambda r: r["pdr"][0] if r["pdr"][0] == r["pdr"][0] else -1)
        fastest = min(headline_rows, key=lambda r: r["mean_interruption_ms"][0] if r["mean_interruption_ms"][0] == r["mean_interruption_ms"][0] else 1e9)
        slowest = max(headline_rows, key=lambda r: r["mean_interruption_ms"][0] if r["mean_interruption_ms"][0] == r["mean_interruption_ms"][0] else -1)
        lines.append(f"- **Best reliability:** `{best_pdr['scenario']}` reaches "
                     f"**{fmt(*best_pdr['pdr'])}%** packet-weighted PDR.")
        lines.append(f"- **Fastest switch recovery:** `{fastest['scenario']}` averages "
                     f"**{fmt(*fastest['mean_interruption_ms'], decimals=1)} ms** service interruption.")
        lines.append(f"- **Slowest switch recovery:** `{slowest['scenario']}` averages "
                     f"**{fmt(*slowest['mean_interruption_ms'], decimals=1)} ms** service interruption.")
        if gm:
            lines.append(f"- **Gauss-Markov RSSI abruptness:** p95 |ΔRSSI| = "
                         f"**{fmt(*gm['p95_abs_rssi_delta'])} dB** — the reference point Section 3 checks against.")
    lines.append("")
    lines.append("| Scenario | Runs | Switch events /100s | Burstiness (CoV) | "
                 "Mean \\|ΔRSSI\\| (dB) | p95 \\|ΔRSSI\\| (dB) | Mean interruption (ms) | Packet-weighted PDR (%) |")
    lines.append("|---|---|---|---|---|---|---|---|")
    for row in headline_rows:
        lines.append(
            f"| {row['scenario']} | {row['n_runs']} | "
            f"{fmt(*row['events_per_100s'])} | {fmt(*row['burstiness'])} | "
            f"{fmt(*row['mean_abs_rssi_delta'])} | {fmt(*row['p95_abs_rssi_delta'])} | "
            f"{fmt(*row['mean_interruption_ms'], decimals=1)} | "
            f"{fmt(*row['pdr']) if row['pdr'][0] == row['pdr'][0] else 'n/a'} |"
        )
    lines.append("")
    if headline_rows:
        # Plain markdown image syntax here, one per line. The chart-grid div
        # wrapping is applied later by regex on the *converted* HTML output
        # (see _wrap_chart_grids), not embedded in the markdown source —
        # Python-Markdown treats raw HTML blocks as opaque and won't convert
        # markdown image syntax nested inside them.
        lines.append("![Switching frequency](report_assets/chart_events_per_100s.png)")
        lines.append("")
        lines.append("![Switching burstiness](report_assets/chart_burstiness.png)")
        lines.append("")
        lines.append("![RSSI abruptness](report_assets/chart_rssi_abruptness.png)")
        lines.append("")
        lines.append("![Service interruption](report_assets/chart_interruption.png)")
        lines.append("")
        lines.append("_Figure: Switching frequency, burstiness, RSSI-change abruptness, and mean "
                     f"service interruption across scenarios at {BASELINE_SPEED} m/s._")
        lines.append("")

    # ---- Section 2: Speed sensitivity ----
    lines.append("## 2. Waypoint Speed Sensitivity (0.5 / 2.0 / 5.0 m/s)")
    lines.append("")
    lines.append("This section isolates robot speed as the variable of interest, per the "
                 "enhancement plan's 3-level speed comparison (section 2.3): 0.5 m/s "
                 "(precision work), 2.0 m/s (movement), 5.0 m/s (existing baseline).")
    lines.append("")
    lines.append("### Section Summary")
    lines.append("")
    for scenario in ["patrol", "transport", "work"]:
        rows_s = [r for r in speed_rows if r["scenario"] == scenario]
        rows_s.sort(key=lambda r: float(r["speed"]))
        if len(rows_s) >= 2:
            lo, hi = rows_s[0], rows_s[-1]
            lines.append(f"- `{scenario}` from **{lo['speed']}** to **{hi['speed']} m/s**: "
                         f"p95 |ΔRSSI| {lo['p95_abs_rssi_delta'][0]:.2f} → "
                         f"{hi['p95_abs_rssi_delta'][0]:.2f} dB "
                         f"({'+' if hi['p95_abs_rssi_delta'][0] >= lo['p95_abs_rssi_delta'][0] else ''}"
                         f"{hi['p95_abs_rssi_delta'][0] - lo['p95_abs_rssi_delta'][0]:.2f} dB).")
    lines.append("")
    lines.append("| Scenario | Speed (m/s) | Runs | Switch events /100s | Burstiness (CoV) | "
                 "Mean \\|ΔRSSI\\| (dB) | p95 \\|ΔRSSI\\| (dB) |")
    lines.append("|---|---|---|---|---|---|---|")
    for row in speed_rows:
        lines.append(
            f"| {row['scenario']} | {row['speed']} | {row['n_runs']} | "
            f"{fmt(*row['events_per_100s'])} | {fmt(*row['burstiness'])} | "
            f"{fmt(*row['mean_abs_rssi_delta'])} | {fmt(*row['p95_abs_rssi_delta'])} |"
        )
    lines.append("")
    lines.append("_Figure interpretation:_ RSSI-change abruptness increases with speed across "
                 "all three robot types — the clearest, most physically-expected result in this "
                 "study. Faster movement covers more distance between fixed-interval samples, so "
                 "signal strength changes more per second.")
    lines.append("")

    # ---- Section 3: Verdict ----
    lines.append("## 3. Verdict Against the Enhancement Plan's Predictions")
    lines.append("")
    lines.append("The enhancement plan predicts two effects of switching from Gauss-Markov to "
                 "Waypoint mobility: switching events should become more concentrated "
                 "(vs. dispersed), and RSSI variation should become more abrupt in specific "
                 "zones (vs. gradual).")
    lines.append("")
    lines.append("### Section Summary")
    lines.append("")
    if gm and wp_rows:
        lines.append(
            f"- **Switching events dispersed → concentrated**: "
            f"{'CONFIRMED' if burst_confirmed else 'NOT CONFIRMED'} — "
            f"Gauss-Markov burstiness (CoV) = **{gm['burstiness'][0]:.2f}**, "
            f"waypoint average = **{wp_burst_mean:.2f}**."
        )
        lines.append(
            f"- **RSSI variation gradual → abrupt-change zones**: "
            f"{'CONFIRMED' if rssi_confirmed else 'NOT CONFIRMED'} — "
            f"Gauss-Markov p95 |ΔRSSI| = **{gm['p95_abs_rssi_delta'][0]:.2f} dB**, "
            f"waypoint average = **{wp_rssi_p95_mean:.2f} dB**."
        )
    else:
        lines.append("Insufficient data to compare (need both gaussmarkov_baseline and "
                     "at least one waypoint scenario at the baseline speed).")

    md_content = "\n".join(lines) + "\n"
    md_path = out_path.with_suffix(".md")
    md_path.write_text(md_content)
    print(f"Wrote {md_path}")

    if not args.no_pdf:
        try:
            import markdown as md_lib
        except ImportError as exc:
            print(f"Skipping PDF (missing dependency: {exc})", file=sys.stderr)
            return
        try:
            from weasyprint import HTML
        except ImportError:
            HTML = None

        html_body = md_lib.markdown(md_content, extensions=["tables", "fenced_code", "nl2br"])
        html_body = _wrap_chart_grids(html_body)
        title = out_path.stem.replace("_", " ")
        html_doc = f"""<!doctype html>
<html>
  <head>
    <meta charset="utf-8" />
    <title>{title}</title>
    <style>
      @page {{
        size: A4;
        margin: 20mm 20mm 30mm 20mm;
        @bottom-center {{
          content: "Page " counter(page) " of " counter(pages);
          font-size: 10pt;
          color: #666;
          font-family: Arial, sans-serif;
        }}
      }}
      @page:first {{ @bottom-center {{ content: ""; }} }}
      body {{ font-family: Arial, sans-serif; font-size: 11pt; line-height: 1.45; color: #222; }}
      h1, h2, h3 {{ page-break-after: avoid; page-break-inside: avoid; }}
      h1 {{ color: #1f4e79; border-bottom: 3px solid #1f4e79; padding-bottom: 10px; margin: 0 0 18px; font-size: 22pt; }}
      h2 {{ color: #2e5f8a; margin-top: 30px; margin-bottom: 10px; border-bottom: 2px solid #2e5f8a; padding-bottom: 5px; font-size: 16pt; }}
      h3 {{ color: #2e5f8a; margin-top: 18px; margin-bottom: 8px; font-size: 13pt; }}
      p {{ margin: 8px 0; }}
      ul {{ margin: 8px 0 12px 20px; }}
      li {{ margin: 4px 0; }}
      blockquote {{ border-left: 4px solid #2e5f8a; margin: 12px 0; padding: 4px 16px; background: #f5f8fb; color: #444; }}
      table {{ border-collapse: collapse; width: 100%; margin: 15px 0; font-size: 0.9em; table-layout: fixed; page-break-inside: auto; }}
      thead {{ display: table-header-group; }}
      tbody {{ display: table-row-group; }}
      tr {{ page-break-inside: avoid; page-break-after: auto; }}
      th {{ background-color: #1f4e79; color: white; padding: 10px 8px; text-align: center; font-weight: bold; border: 1px solid #ddd; word-wrap: break-word; }}
      td {{ padding: 8px 6px; text-align: center; border: 1px solid #ddd; word-wrap: break-word; vertical-align: top; }}
      tr:nth-child(even) {{ background-color: #f5f5f5; }}
      tr:nth-child(odd) {{ background-color: white; }}
      code {{ background: #f4f4f4; padding: 2px 4px; border-radius: 3px; font-family: "DejaVu Sans Mono", monospace; font-size: 0.95em; }}
      img {{ max-width: 100%; height: auto; display: block; margin: 12px auto; }}
      .chart-grid {{ font-size: 0; margin: 10px 0 16px; }}
      .chart-grid p {{ display: inline-block; width: 48%; margin: 0 1% 14px; vertical-align: top; }}
      .chart-grid img {{ width: 100%; margin: 0; }}
    </style>
  </head>
  <body>
    {html_body}
  </body>
</html>"""
        pdf_path = out_path.with_suffix(".pdf")
        if HTML is not None:
            HTML(string=html_doc, base_url=str(out_path.parent)).write_pdf(str(pdf_path))
        else:
            from xhtml2pdf import pisa
            with open(pdf_path, "wb") as f:
                result = pisa.CreatePDF(src=html_doc, dest=f, encoding="utf-8")
            if result.err:
                print("PDF generation failed (xhtml2pdf reported errors).", file=sys.stderr)
                return
        print(f"Wrote {pdf_path}")


if __name__ == "__main__":
    main()
